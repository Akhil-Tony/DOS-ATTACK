# ESP32 S2 FTM Measurements
=========================

FTM measurements were created using several ESP32-S2 devices. They are presented in two different formats: rosbag (http://wiki.ros.org/rosbag) format and matlab format.

## ROS BAG records

The measurements can be found in the directories:

- AC
- Indoor
- Outdoor

The ROS messages are of type ESP32S2FTMRangingExtra and ESP32S2FTMRanging. These message types can be found in the following repository: https://github.com/valentinbarral/rosmsgs

The following fields are included within each message:

- anchorId: Identifier of the module that acted as beaconin the measurement.
- rtt_raw:   RTT   value   averaged   among   the   differentframes sent. In nanoseconds.
- rtt_est:  RTT  estimation  created  by  the  ESP32-S2firmware. In nanoseconds.
- dist_est:  Distance  estimation.  Internally,  the  rttestvalue is used to calculate this value. In meters.
- num_frames: Number of frames successfully sent dur-ing the RTT communication.
- frames: A list of all successfully sent frames.

Each individual frame includes the following information:
- rssi: Received signal strength. In dBm.
- rtt: RTT value in that frame. In nanoseconds.
- t1:  Outgoing  timestamp  of  the  first  packet  from  thesender. In picoseconds.
- t2: Timestamp of reception of the ranging request at thereceiver. In picoseconds.
- t3: Timestamp of the response message at the receiver.In picoseconds.
- t4:  Timestamp  of  reception  of  the  response  messagefrom the receiver at the sender. In picoseconds.

## Matlab logs

The measurements in matlab format are in the .mat file. This file includes four 1x1 struc elements:

- indoor
- outdoor20
- outdoor40
- sa

Each of these structures has the following fields:

- actualDist: Actual distance.
- rttRaw: RTT   value   averaged   among   the   differentframes sent. In nanoseconds.
- estDistRaw: Distance estimate using rttRaw.
- absErrRaw: Absolute distance error of estDistRaw.
- rttEst: RTT  estimation  created  by  the  ESP32-S2firmware. In nanoseconds.
- estDistEst: Distance estimate using rttEst.
- absErrEst: Absolute distance error of estDistEst.
- varRtt: variance of RTT
- meanRtt: mean of RTT
- countRtt: count of RTT
- meanRss: mean RSSI
- distEst: Distance estimate using own algorithm.


More info about this measurements can be found in the next paper (under review):

Fine Time Measurement in low-cost microprocessors for the Internet of Things